/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

//https://www.youtube.com/watch?v=dfhmTyRTCSQ&ab_channel=BroCode

package guicalculator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GUICalculator implements ActionListener {

    JFrame frame;
    JTextField textfield;
    JButton[] numberButtons = new JButton[10]; 
    JButton[] functionButtons = new JButton[9]; 
    JButton addButton, subButton, mulButton, divButton;
    JButton decButton, equButton, delButton, clrButton, negButton;
    JPanel panel;

    Font myFont = new Font("Times New Roman", Font.BOLD, 30);

    double num1 = 0, num2 = 0, result = 0;
    char operator;
    StringBuilder calculation = new StringBuilder(); 

    // Pompompurin color palette
    Color pomPomYellow = new Color(255, 221, 51); 
    Color pomPomBrown = new Color(150, 75, 0); 
    Color cream = new Color(255, 253, 208); 
    Color white = Color.WHITE;

    GUICalculator() {
        frame = new JFrame("Nyeh Calculator");
        ImageIcon icon = new ImageIcon(getClass().getResource("/nyot.png"));
        frame.setIconImage(icon.getImage());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420, 550);
        frame.setLayout(null);

        frame.getContentPane().setBackground(cream);

        textfield = new JTextField();
        textfield.setBounds(50, 25, 300, 50);
        textfield.setFont(myFont);
        textfield.setEditable(false);
        textfield.setBackground(pomPomYellow); 
        textfield.setForeground(pomPomBrown); 
        textfield.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        textfield.setBorder(BorderFactory.createLineBorder(pomPomBrown, 2, true));

        addButton = new RoundedButton("+");
        subButton = new RoundedButton("-");
        mulButton = new RoundedButton("x");
        divButton = new RoundedButton("÷");
        decButton = new RoundedButton(".");
        equButton = new RoundedButton("=");
        delButton = new RoundedButton("Del");
        clrButton = new RoundedButton("Clr");
        negButton = new RoundedButton("(-)"); 

        functionButtons[0] = addButton;
        functionButtons[1] = subButton;
        functionButtons[2] = mulButton;
        functionButtons[3] = divButton;
        functionButtons[4] = decButton;
        functionButtons[5] = equButton;
        functionButtons[6] = delButton; 
        functionButtons[7] = clrButton; 
        functionButtons[8] = negButton; 

        for (int i = 0; i < 4; i++) {
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(myFont);
            functionButtons[i].setFocusable(false);
            functionButtons[i].setBackground(pomPomBrown);  
            functionButtons[i].setForeground(white);
        }

        for (int i = 4; i < 9; i++) {
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(myFont);
            functionButtons[i].setFocusable(false);
            functionButtons[i].setBackground(pomPomYellow);  
            functionButtons[i].setForeground(pomPomBrown);
        }

        for (int i = 0; i < 10; i++) {
            numberButtons[i] = new RoundedButton(String.valueOf(i));
            numberButtons[i].addActionListener(this);
            numberButtons[i].setFont(myFont);
            numberButtons[i].setFocusable(false);
            numberButtons[i].setBackground(pomPomYellow);  
            numberButtons[i].setForeground(pomPomBrown);
        }

        clrButton.setBounds(150, 430, 100, 50);
        delButton.setBounds(250, 430, 100, 50);
        negButton.setBounds(50, 430, 100, 50); 

        panel = new JPanel();
        panel.setBounds(50, 100, 300, 300);
        panel.setLayout(new GridLayout(4, 4, 10, 10));
        panel.setBackground(cream);  

        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(addButton);
        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(subButton);
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(mulButton);
        panel.add(decButton);
        panel.add(numberButtons[0]);
        panel.add(equButton);
        panel.add(divButton);

        frame.add(panel);
        frame.add(negButton); 
        frame.add(delButton);
        frame.add(clrButton);
        frame.add(textfield);
        frame.setVisible(true);
    }

    public static void main(String[] args) {
        GUICalculator calc = new GUICalculator();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        for (int i = 0; i < 10; i++) {
            if (e.getSource() == numberButtons[i]) {
                calculation.append(i);
                textfield.setText(calculation.toString());
            }
        }
        if (e.getSource() == decButton) {
            if (!calculation.toString().contains(".")) {
                calculation.append(".");
                textfield.setText(calculation.toString());
            }
        }

        if (e.getSource() == addButton || e.getSource() == subButton || e.getSource() == mulButton || e.getSource() == divButton) {
            if (calculation.length() > 0) {
                char lastChar = calculation.charAt(calculation.length() - 1);
                if (lastChar != ' ' && lastChar != '+' && lastChar != '-' && lastChar != 'x' && lastChar != '÷') {
                    num1 = Double.parseDouble(calculation.toString().trim());
                    operator = ((JButton) e.getSource()).getText().charAt(0);
                    calculation.append(" " + operator + " ");
                    textfield.setText(calculation.toString());
                } else {
                    calculation.setCharAt(calculation.length() - 1, operator);
                    textfield.setText(calculation.toString());
                }
            }
        }

        if (e.getSource() == equButton) {
            String[] tokens = calculation.toString().trim().split(" ");
            if (tokens.length < 3) return;

            num2 = Double.parseDouble(tokens[2]);

            switch (operator) {
                case '+':
                    result = num1 + num2;
                    break;
                case '-':
                    result = num1 - num2;
                    break;
                case 'x':
                    result = num1 * num2;
                    break;
                case '÷':
                    result = num1 / num2;
                    break;
            }

            textfield.setText((result % 1 == 0) ? String.valueOf((int) result) : String.valueOf(result));
            calculation.setLength(0);
        }

        if (e.getSource() == clrButton) {
            textfield.setText("");
            calculation.setLength(0);
        }

        if (e.getSource() == delButton) {
            if (calculation.length() > 0) {
                calculation.setLength(calculation.length() - 1);
                textfield.setText(calculation.toString());
            }
        }

        if (e.getSource() == negButton) {
            if (calculation.length() == 0) {
                calculation.append("-");
            } else {
                String currentInput = calculation.toString().trim();
                if (currentInput.startsWith("-")) {
                    calculation.deleteCharAt(0);
                } else {
                    calculation.insert(0, '-');
                }
            }
            textfield.setText(calculation.toString());
        }
    }

    class RoundedButton extends JButton {
        public RoundedButton(String label) {
            super(label);
            setOpaque(false);
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorder(BorderFactory.createLineBorder(new Color(204, 0, 0), 2, true));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
            super.paintComponent(g);
            g2.dispose();
        }
    }
}
